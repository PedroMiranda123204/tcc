<?php
include("includes/conexao.php");
include("includes/functions.php");

$resumo = dashboard($conexao);
$vencendo = produtosVencendo($conexao, 7);
$criticos = produtosCriticos($conexao, 5);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Dashboard - Controle de Estoque</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="dashboard-body">
<?php include("includes/nav.php"); ?>

<main class="dashboard-main">
        <section class="dashboard-topbar">
            <div class="dashboard-search">
                <span class="search-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8" />
                        <path d="m21 21-4.2-4.2" />
                    </svg>
                </span>
                <input type="search" placeholder="Buscar produto">
            </div>
        </section>

        <section class="dashboard-content">
            <div class="dashboard-crumb">
                <span>Dashboard</span>
                <span class="crumb-sep">&gt;</span>
                <span>Resumo do Estoque</span>
            </div>

            <section class="kpi-grid">
                <article class="kpi-card">
                    <span class="kpi-label">Total de Produtos</span>
                    <span class="kpi-value"><?= $resumo['total_produtos']; ?></span>
                    <span class="kpi-detail">Ativos no sistema</span>
                </article>
                <article class="kpi-card">
                    <span class="kpi-label">Valor em Estoque</span>
                    <span class="kpi-value">R$ <?= number_format($resumo['valor_estoque'], 2, ",", "."); ?></span>
                    <span class="kpi-detail">Valor estimado</span>
                </article>
                <article class="kpi-card">
                    <span class="kpi-label">Vencendo em 7 dias</span>
                    <span class="kpi-value strong-yellow"><?= $resumo['produtos_vencendo']; ?></span>
                    <span class="kpi-detail">Próximos vencimentos</span>
                </article>
                <article class="kpi-card">
                    <span class="kpi-label">Produtos Vencidos</span>
                    <span class="kpi-value strong-red"><?= $resumo['produtos_vencidos']; ?></span>
                    <span class="kpi-detail">Ação necessária</span>
                </article>
                <article class="kpi-card">
                    <span class="kpi-label">Estoque Baixo</span>
                    <span class="kpi-value strong-purple"><?= $resumo['estoque_baixo']; ?></span>
                    <span class="kpi-detail">≤ 5 unidades</span>
                </article>
                <article class="kpi-card">
                    <span class="kpi-label">Movimentações</span>
                    <span class="kpi-value"><?= $resumo['total_movimentacoes']; ?></span>
                    <span class="kpi-detail">Registradas</span>
                </article>
            </section>

            <?php
            // [classe, rótulo, valor, badge, ícone(paths separados por |)]
            $situacao = [
                ['total',    'Total de Produtos',   $resumo['total_produtos'],   'Ativo',
                    'M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4a2 2 0 0 0 1-1.73Z|M3.3 7 12 12l8.7-5|M12 22V12'],
                ['vencendo', 'Vencendo em Breve',   $resumo['produtos_vencendo'], '7 dias',
                    'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20Z|M12 6v6l4 2'],
                ['vencidos', 'Produtos Vencidos',   $resumo['produtos_vencidos'], 'Ação necessária',
                    'm21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z|M12 9v4|M12 17h.01'],
                ['baixo',    'Estoque Baixo',       $resumo['estoque_baixo'],    '≤ 5 un.',
                    'M3 17h4v4H3z|M10 11h4v10h-4z|M17 4h4v17h-4z'],
            ];
            $totalGeral = max((int)$resumo['total_produtos'], 1);
            ?>

            <section class="dashboard-panel">
                <div class="panel-head">
                    <div>
                        <span class="panel-kicker">Visão Geral</span>
                        <h2>Situação Geral do Estoque</h2>
                    </div>
                    <span class="live-pill"><span class="live-dot"></span>Atualizado agora</span>
                </div>
                <div class="stat-grid">
                    <?php foreach ($situacao as [$classe, $rotulo, $valor, $badge, $paths]):
                        $pct = round($valor / $totalGeral * 100, 1); ?>
                    <div class="stat stat--<?= $classe ?>">
                        <div class="stat-top">
                            <div class="stat-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <?php foreach (explode('|', $paths) as $d): ?><path d="<?= $d ?>"/><?php endforeach; ?>
                                </svg>
                            </div>
                            <span class="stat-badge"><?= $badge ?></span>
                        </div>
                        <div class="stat-num" data-count="<?= (int)$valor ?>">0</div>
                        <div class="stat-label"><?= $rotulo ?></div>
                        <div class="stat-bar"><div class="stat-bar-fill" data-width="<?= $pct ?>"></div></div>
                        <div class="stat-foot"><span>Do total do estoque</span><strong><?= str_replace('.', ',', $pct) ?>%</strong></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <section class="dashboard-lower">
                <section class="dashboard-table-panel">
                    <div class="table-title">
                        <h2>Produtos Vencendo em Breve</h2>
                        <span class="table-tag tag-warning"><?= $resumo['produtos_vencendo']; ?> itens</span>
                    </div>
                    <table class="responsive-table">
                        <thead>
                            <tr><th>Código</th><th>Nome</th><th>Lote</th><th>Validade</th><th>Qtd</th></tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($vencendo) > 0): ?>
                                <?php while ($p = mysqli_fetch_assoc($vencendo)): ?>
                                <tr>
                                    <td><?= htmlspecialchars($p['codigo']); ?></td>
                                    <td><?= htmlspecialchars($p['nome']); ?></td>
                                    <td><?= htmlspecialchars($p['lote']); ?></td>
                                    <td><?= date('d/m/Y', strtotime($p['validade'])); ?></td>
                                    <td><?= $p['quantidade']; ?></td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="5" class="empty-row">Nenhum produto vencendo nos próximos 7 dias.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </section>

                <section class="dashboard-table-panel">
                    <div class="table-title">
                        <h2>Produtos com Estoque Baixo</h2>
                        <span class="table-tag tag-danger"><?= $resumo['estoque_baixo']; ?> itens</span>
                    </div>
                    <table class="responsive-table">
                        <thead>
                            <tr><th>Código</th><th>Nome</th><th>Lote</th><th>Qtd</th><th>Categoria</th></tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($criticos) > 0): ?>
                                <?php while ($p = mysqli_fetch_assoc($criticos)): ?>
                                <tr>
                                    <td><?= htmlspecialchars($p['codigo']); ?></td>
                                    <td><?= htmlspecialchars($p['nome']); ?></td>
                                    <td><?= htmlspecialchars($p['lote']); ?></td>
                                    <td><?= $p['quantidade']; ?></td>
                                    <td><?= htmlspecialchars($p['categoria']); ?></td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="5" class="empty-row">Nenhum produto com estoque baixo.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </section>
            </section>
        </section>
    </main>

<script src="assets/js/situacao-estoque.js"></script>
</body>
</html>