<?php
$paginaAtual = basename($_SERVER['PHP_SELF']);
$menu = [
    'index.php' => ['texto' => 'Estoque', 'href' => 'index.php', 'icon' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10.5 12 3l9 7.5V21h-6v-6H9v6H3z"/></svg>'],
    'dashboard.php' => ['texto' => 'Dashboard', 'href' => 'dashboard.php', 'icon' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19h16"/><path d="M6 15l4-4 4 4 4-7"/></svg>'],
    'saida.php' => ['texto' => 'Saídas', 'href' => 'saida.php', 'icon' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16"/><path d="M4 12h16"/><path d="M4 17h11"/><path d="M17 13l4 4-4 4"/><path d="M21 17h-10"/></svg>'],
    'movimentacoes.php' => ['texto' => 'Movimentações', 'href' => 'movimentacoes.php', 'icon' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16"/><path d="M4 12h16"/><path d="M4 17h11"/></svg>'],
    'relatorios.php' => ['texto' => 'Relatórios', 'href' => 'relatorios.php', 'icon' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18"/><path d="M4 21V6l8-4 8 4v15"/><path d="M9 9h6"/><path d="M9 13h6"/></svg>'],
    'avisos.php' => ['texto' => 'Avisos', 'href' => 'avisos.php', 'icon' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7.5 0 10h12c3-2.5 0-3 0-10"/><path d="M10.3 21h3.4"/></svg>'],
];

// Caminho da logo do estabelecimento.
// Basta colocar o arquivo da logo em assets/img/logo.png que ela aparece automaticamente aqui.
$caminhoLogo = 'assets/img/logo.jpeg';
$logoExiste = file_exists(__DIR__ . '/../' . $caminhoLogo);
?>
<header class="topo">
    <div class="topo-barra">
        <div class="logo-area">
            <button type="button" class="menu-toggle" id="menuToggle" aria-label="Abrir menu" aria-expanded="false" aria-controls="navbarMenu">
                <span class="icone-menu">
                    <span></span>
                    <span></span>
                    <span></span>
                </span>
            </button>

            <?php if ($logoExiste): ?>
                <img src="<?= htmlspecialchars($caminhoLogo, ENT_QUOTES, 'UTF-8'); ?>" alt="Logo do estabelecimento">
            <?php else: ?>
                <div class="logo-placeholder">LOGO</div>
            <?php endif; ?>

            <span class="marca-texto">
                Controle de Estoque
                <small>Gestão de insumos</small>
            </span>
        </div>
    </div>

    <!-- Os itens abaixo só aparecem depois que o botão acima é clicado -->
    <nav class="navbar" id="navbarMenu">
        <?php foreach ($menu as $arquivo => $item): ?>
            <a href="<?= htmlspecialchars($item['href'], ENT_QUOTES, 'UTF-8'); ?>" class="<?= $paginaAtual === $arquivo ? 'active' : ''; ?> nav-link">
                <span class="nav-icon"><?= $item['icon']; ?></span>
                <span class="nav-label"><?= htmlspecialchars($item['texto'], ENT_QUOTES, 'UTF-8'); ?></span>
            </a>
        <?php endforeach; ?>
    </nav>
</header>
<script src="assets/js/menu.js"></script>