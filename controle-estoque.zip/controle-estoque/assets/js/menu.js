/* =========================================================
   Controle do menu hambúrguer
   Mostra/esconde os itens da navbar ao clicar no botão
   ========================================================= */
document.addEventListener('DOMContentLoaded', function () {
    var botao = document.getElementById('menuToggle');
    var navbar = document.getElementById('navbarMenu');

    if (!botao || !navbar) return;

    function abrirMenu() {
        navbar.classList.add('aberto');
        botao.classList.add('aberto');
        botao.setAttribute('aria-expanded', 'true');
    }

    function fecharMenu() {
        navbar.classList.remove('aberto');
        botao.classList.remove('aberto');
        botao.setAttribute('aria-expanded', 'false');
    }

    function alternarMenu() {
        var estaAberto = navbar.classList.contains('aberto');
        if (estaAberto) {
            fecharMenu();
        } else {
            abrirMenu();
        }
    }

    botao.addEventListener('click', function (evento) {
        evento.stopPropagation();
        alternarMenu();
    });

    // Fecha o menu ao clicar fora dele
    document.addEventListener('click', function (evento) {
        var cliqueForaDoMenu = !navbar.contains(evento.target) && !botao.contains(evento.target);
        if (cliqueForaDoMenu && navbar.classList.contains('aberto')) {
            fecharMenu();
        }
    });

    // Fecha o menu ao pressionar ESC
    document.addEventListener('keydown', function (evento) {
        if (evento.key === 'Escape' && navbar.classList.contains('aberto')) {
            fecharMenu();
        }
    });
});