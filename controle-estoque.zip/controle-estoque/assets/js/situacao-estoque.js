// Anima contadores e barras do painel "Situação Geral do Estoque"
document.querySelectorAll('.stat-num').forEach(el => {
    const alvo = +el.dataset.count, ini = performance.now();
    requestAnimationFrame(function passo(t) {
        const p = Math.min((t - ini) / 900, 1);
        el.textContent = Math.round(alvo * (1 - (1 - p) ** 3));
        if (p < 1) requestAnimationFrame(passo);
    });
});
requestAnimationFrame(() =>
    document.querySelectorAll('.stat-bar-fill').forEach(b => b.style.width = b.dataset.width + '%')
);
