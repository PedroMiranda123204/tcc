<?php
session_start();

include('includes/conexao.php');
include('includes/functions.php');

if (isset($_SESSION['usuario_logado']) && $_SESSION['usuario_logado']) {
    header('Location: index.php');
    exit;
}

$erroLogin = '';
$erroCadastro = '';
$totalUsuarios = contarUsuarios($conexao);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['entrar'])) {
        $usuario = trim($_POST['txtUser'] ?? '');
        $senha = trim($_POST['txtSenha'] ?? '');

        $usuarioAutenticado = autenticarUsuario($conexao, $usuario, $senha);

        if ($usuarioAutenticado) {
            $_SESSION['usuario_logado'] = true;
            $_SESSION['usuario_nome'] = $usuarioAutenticado['nome_usuario'];
            header('Location: index.php');
            exit;
        }

        $erroLogin = 'Usuário ou senha inválidos.';
    }

    if (isset($_POST['cadastrar_funcionario'])) {
        $usuario = trim($_POST['nome_usuario_cadastro'] ?? '');
        $senha = trim($_POST['senha_cadastro'] ?? '');

        if ($usuario === '') {
            $erroCadastro = 'Informe o nome do funcionário.';
        } elseif ($senha === '') {
            $erroCadastro = 'Informe a senha do funcionário.';
        } elseif (strlen($senha) < 3) {
            $erroCadastro = 'A senha deve ter pelo menos 3 caracteres.';
        } else {
            $sqlVerifica = "SELECT id FROM usuarios WHERE nome_usuario = ? LIMIT 1";
            $stmt = mysqli_prepare($conexao, $sqlVerifica);
            mysqli_stmt_bind_param($stmt, 's', $usuario);
            mysqli_stmt_execute($stmt);
            $resultado = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($resultado) > 0) {
                $erroCadastro = 'Este nome de funcionário já está cadastrado.';
            } else {
                $sucessoCadastro = registrarUsuario($conexao, $usuario, $senha);

                if ($sucessoCadastro) {
                    $_SESSION['usuario_logado'] = true;
                    $_SESSION['usuario_nome'] = $usuario;
                    header('Location: index.php');
                    exit;
                }

                $erroCadastro = 'Não foi possível cadastrar o funcionário.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="assets/style.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
  <title>Login</title>
</head>
<body class="login-page">
    <div class="login-shell">
        <div class="login-switch" aria-label="Alternar entre telas de acesso">
            <button type="button" class="switch-btn active" data-screen="login">Entrar</button>
            <button type="button" class="switch-btn" data-screen="register">Cadastrar funcionário</button>
        </div>

        <div class="auth-screen active" id="screen-login">
            <div class="login-card">
                <div class="login-panel form-panel">
                    <div class="login-section-header">
                        <span class="login-access-tag">Acesso</span>
                        <h2>Funcionário já existente</h2>
                    </div>

                    <form method="post" action="login.php" class="login-form">
                        <?php if ($erroLogin !== ''): ?>
                            <div class="alert alert-danger login-alert" role="alert"><?= htmlspecialchars($erroLogin); ?></div>
                        <?php endif; ?>

                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="usuario" name="txtUser" placeholder="Digite seu usuário" required>
                            <label for="usuario" class="form-label">Nome do usuário</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="password" class="form-control" id="password" name="txtSenha" placeholder="Digite sua senha" required>
                            <label for="password" class="form-label">Senha</label>
                        </div>
                        <button type="submit" name="entrar" class="login-button">Entrar</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="auth-screen" id="screen-register">
            <div class="login-card login-card-register">
                <div class="login-panel login-side">
                    <div class="login-section-header login-side-header">
                        <span class="login-access-tag side-tag">Cadastro</span>
                        <h2><?php echo $totalUsuarios === 0 ? 'Primeiro cadastro' : 'Cadastrar novo funcionário'; ?></h2>
                    </div>

                    <div class="login-brand-box">
                        <div class="login-brand">Controle de Estoque</div>
                        <p class="login-subtitle">Gestão inteligente de insumos e produtos.</p>
                    </div>

                    <div class="login-info">
                        <p><?php echo $totalUsuarios === 0 ? 'Ainda não há funcionários cadastrados. Crie o primeiro acesso para continuar.' : 'Cadastre outro usuário para entrar no sistema.'; ?></p>
                    </div>

                    <form method="post" action="login.php" class="login-form login-secondary-form">
                        <?php if ($erroCadastro !== ''): ?>
                            <div class="alert alert-warning login-alert" role="alert"><?= htmlspecialchars($erroCadastro); ?></div>
                        <?php endif; ?>

                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="nome_usuario_cadastro" name="nome_usuario_cadastro" placeholder="Digite o nome do funcionário" required>
                            <label for="nome_usuario_cadastro" class="form-label">Nome do funcionário</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="password" class="form-control" id="senha_cadastro" name="senha_cadastro" placeholder="Crie uma senha" required>
                            <label for="senha_cadastro" class="form-label">Senha</label>
                        </div>
                        <button type="submit" name="cadastrar_funcionario" class="login-button secondary">Cadastrar funcionário</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const buttons = document.querySelectorAll('.switch-btn');
            const screens = document.querySelectorAll('.auth-screen');

            buttons.forEach(function (button) {
                button.addEventListener('click', function () {
                    const target = this.dataset.screen;

                    buttons.forEach(function (btn) {
                        btn.classList.toggle('active', btn === button);
                    });

                    screens.forEach(function (screen) {
                        screen.classList.toggle('active', screen.id === 'screen-' + target);
                    });
                });
            });
        });
    </script>
</body>
</html>